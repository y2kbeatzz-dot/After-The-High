INSTALL:
1. Go to chrome://extensions/
2. Turn on Developer mode
3. Click Load unpacked
4. Select the after-the-high-extension folder

The extension popup can open the full AFTER THE HIGH website and jump directly to My Story, All Drugs, Vaping, Programs, Help, and FAQ.
