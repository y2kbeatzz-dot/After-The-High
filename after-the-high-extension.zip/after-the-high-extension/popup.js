
const SITE='https://y2kbeatzz-dot.github.io/After-The-High/';
document.querySelectorAll('[data-url]').forEach(b=>{
  b.addEventListener('click',()=>chrome.tabs.create({url:b.dataset.url}));
});
document.getElementById('copy').addEventListener('click',async()=>{
  const t=document.getElementById('toast');
  try{
    await navigator.clipboard.writeText(SITE);
    t.textContent='Website link copied';
  }catch{
    t.textContent=SITE;
  }
  setTimeout(()=>t.textContent='',1800);
});
